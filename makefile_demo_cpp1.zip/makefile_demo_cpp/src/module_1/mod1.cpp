#include <iostream>
#include <cmath>

int main() {
    std::cout << sqrt(14) << std::endl;
    return 0;
} 
