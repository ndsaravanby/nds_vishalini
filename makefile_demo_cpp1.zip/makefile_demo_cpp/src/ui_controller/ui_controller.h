#pragma once

#include "db_mgr.h"

class UI_Controller {
	public:
		UI_Controller();
		void show();
        void get_emp_id_and_show_details();
};
