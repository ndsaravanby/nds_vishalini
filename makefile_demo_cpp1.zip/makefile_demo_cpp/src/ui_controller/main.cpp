#include "ui_controller.h"

int main() {

	UI_Controller ui_obj;
	ui_obj.show();
	return 0;
}
