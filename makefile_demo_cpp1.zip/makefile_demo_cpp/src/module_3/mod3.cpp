#include <iostream>
#include "mod2.h"

int main() {
    std::cout << "Module-03\n";
    fun2();
}
