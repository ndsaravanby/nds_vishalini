#include <iostream>

void f4() {
	std::cout << "I am in f4()\n";
}
