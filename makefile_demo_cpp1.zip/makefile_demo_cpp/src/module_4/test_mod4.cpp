#include <iostream>
#include "mod4.h"

int main() {
    std::cout << "I am testing static lib\n";
    f4();
    return 0;
}
