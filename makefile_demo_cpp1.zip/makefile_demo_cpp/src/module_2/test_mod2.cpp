#include <iostream>
#include "mod2.h"

int main() {
    std::cout << "XXXXXI am testing so\n";   
    fun2();
    return EXIT_SUCCESS;
}
