#include <iostream>

void fun2() {
    std::cout << "Updated... SO\n";
    std::cout << ".SO Implementation:f2() \n" ;
}
