#pragma once

void fun2();
