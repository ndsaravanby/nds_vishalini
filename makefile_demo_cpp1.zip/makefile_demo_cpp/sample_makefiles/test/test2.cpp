#include <iostream>

#include "test2.h"

void test2::operator()() {
			std::cout << "I am functor in test2-------Hopefully u know me\n";
}

