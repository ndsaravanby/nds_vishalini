#pragma once

class test1 {
	public:
test1();
		void operator()(); 
};
