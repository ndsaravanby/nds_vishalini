#pragma once

class test2 {

	public:
		void operator()(); 
};
